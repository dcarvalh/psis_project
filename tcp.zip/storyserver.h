//#define SOCKET_NAME "xxx"
#define MESSAGE_LEN 100
//#define SOCK_ADDRESS "/tmp/sock_16"
#define SOCKET_NAME "my_socket"

typedef struct message{
    char buffer[MESSAGE_LEN];
} message;
