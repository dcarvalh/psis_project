
int gallery_connect(char * host, in_port_t port);
